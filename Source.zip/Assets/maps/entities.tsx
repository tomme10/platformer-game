<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="entities" tilewidth="120" tileheight="120" tilecount="11" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="40" height="40" source="../portal/flag.png"/>
 </tile>
 <tile id="1">
  <image width="120" height="120" source="../orb/corruptedOrb1.png"/>
 </tile>
 <tile id="2">
  <image width="70" height="30" source="../tutorial.png"/>
 </tile>
 <tile id="3">
  <image width="20" height="20" source="../flames/flames1.png"/>
 </tile>
 <tile id="4">
  <image width="20" height="20" source="../flames/flames2.png"/>
 </tile>
 <tile id="5">
  <image width="20" height="20" source="../flames/flames3.png"/>
 </tile>
 <tile id="6">
  <image width="20" height="20" source="../flames/flames4.png"/>
 </tile>
 <tile id="7">
  <image width="20" height="20" source="../flames/flames5.png"/>
 </tile>
 <tile id="8">
  <image width="20" height="20" source="../flames/flames6.png"/>
 </tile>
 <tile id="9">
  <image width="20" height="20" source="../flames/flames7.png"/>
 </tile>
 <tile id="10">
  <image width="75" height="25" source="../portalTutorial.png"/>
 </tile>
</tileset>
